package com.exponent.service;

public interface UserService {
	
	public void addUserDetail();
	
	public void displayAlluser();
	
	public void displaySingleUser();
	
	public void updateUserDetail();
	
	public void deleteUserDetail();
	
	
}
