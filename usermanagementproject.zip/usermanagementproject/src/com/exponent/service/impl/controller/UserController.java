package com.exponent.service.impl.controller;
import com.exponent.model.*;
import com.exponent.service.*;
import com.exponent.service.impl.*;
import java.util.Scanner;
public class UserController {
	public static void main(String[] args) {
		UserService u = new UserServiceIMPL();
        System.out.println("----user management---");
        Scanner sc = new Scanner(System.in);
        boolean flag=true;
        while(flag) {
        	System.out.println("-------------------");
        	System.out.println(" 1 : add user detail");
        	System.out.println(" 2 : display all user");
        	System.out.println(" 3 : display single user");
        	System.out.println(" 4 : update user detail");
        	System.out.println(" 5 : delete user detail");
        	System.out.println(" 6 : exits");
        	System.out.println(" 7 : enter your choice between 1-7");
        	int ch=sc.nextInt();
        	switch(ch) {
        	case 1 :
        		u.addUserDetail();
        		break;
        	case 2 :
        		u.displayAlluser();
        		break;
        	case 3 :
        		u.displaySingleUser();
        		break;
        	case 4 :
        		u.updateUserDetail();
        		break;
        	case 5 :
        		u.deleteUserDetail();
        		break;
        	case 6 :
        		flag = false;
        			System.out.println("thank you");
        			break;
        	default:
        		System.out.println("invalid choice enter plz enter correct choice");
        	}
        	
        	
        }

	}
}
