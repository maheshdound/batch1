package com.exponent.service.impl;
import com.exponent.service.*;
import java.util.Scanner;
import com.exponent.model.*;
public class UserServiceIMPL implements UserService {
	User[] u = new User[5];

	@Override
	public void addUserDetail() {
    Scanner sc=new Scanner(System.in);
    System.out.println("how many user you want to add");
    int n =sc.nextInt();
    for (int i = 0; i <n; i++) {
		User user=new User();
		
		System.out.println("enter user id");
		user.setUid(sc.nextInt());
		
		System.out.println("enter user name");
		user.setUname(sc.next());
		
		System.out.println("enter useraddress");
		user.setUaddress(sc.next());
		
		System.out.println("enter gender");
		user.setGender(sc.next());
		
		System.out.println("enter salary");
		user.setSalary(sc.nextDouble());
		
		System.out.println("enter contact");
		user.setContact(sc.nextLong());
        
	    System.out.println("user added sucessfull");
		u[i]=user;
		
		
	}
	}

	@Override
	public void displayAlluser() {
     System.out.println("-----display all user-------");
     for (User user : u ) {
    	 if(user!=null)
		System.out.println(user);
	}
	}

	@Override
	public void displaySingleUser() {
    System.out.println("enter user id");
    Scanner sc=new Scanner(System.in);
    int id =sc.nextInt();
    for (User user : u) {
		if(user!=null && user.getUid()==id)
			System.out.println(user);
	}
    
    
	}

	@Override
	public void updateUserDetail() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUserDetail() {
		Scanner sc =new Scanner(System.in);
    System.out.println("enter user id");
    int id =sc.nextInt();
    int index=0;
    for (int i = 0; i < u.length; i++) {
		if(u[i]!=null && u[i].getUid()==id) {
			index=i;
			break;
		}
		
		
		
		
	}
    u[index]=null;

	}
	
	}
	 


