package packages;

public class D {
public static void main(String[] args) {
	System.out.println("d Class method");
	C c1 = new C();
	System.out.println(c1.r);
	System.out.println(c1.name);
	c1.m3();
	
	
}
}
