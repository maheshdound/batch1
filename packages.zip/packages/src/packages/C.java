package packages;

public class C {
	public int r=30;
	public String name="mahesh";
public void m3()
{
System.out.println("m3 method");
B b1 = new B();
System.out.println(b1.q);
System.out.println(b1.middleNames);

b1.m2();

}
}
