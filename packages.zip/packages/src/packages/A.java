package packages;

public class A {
public int p=10;
public String lastNames="dound";
public void m1()
{
System.out.println("m1 method");

}
}

