package packages;

public class B {
public int q=20;
public String middleNames="dattatraya";
public void m2()
{
System.out.println("m2 method");
A a1 = new A();
System.out.println(a1.lastNames);
System.out.println(a1.p);

a1.m1(); 



}
}
