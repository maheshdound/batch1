package returntypestudy;

public class Product {
int pid;
String pnames;

}
