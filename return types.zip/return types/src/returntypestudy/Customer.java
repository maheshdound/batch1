package returntypestudy;

public class Customer {
int cid;
String cnames;
String caddress;
String cmailid;
long ccontact;
}
