package returntypestudy;

public class ProductMgtSystem {
	public Product addProductDetail() {
		Product pro = new Product();
		pro.pid = 10;
		pro.pnames = "pro-15";
		return pro;
	}

	public Order addOrderDetail() {
		Order ord = new Order();
		ord.oid = 3;
		ord.oname = "apple";
		ord.odate = 22.3f;
		ord.oprice = 66.99;
		return ord;
	}

	public Customer addCustomerDetail() {
		Customer cst = new Customer();
		cst.cid = 89;
		cst.cnames = "mahesh";
		cst.caddress = "add-pune";
		cst.cmailid = "khfds@hgg";
		cst.ccontact = 876544;
		return cst;
	}

	public static void main(String[] args) {
		System.out.println("project of product management system");
		ProductMgtSystem p = new ProductMgtSystem();
		Product l = p.addProductDetail();
		System.out.println(l.pid + " " + l.pnames);
		Order o = p.addOrderDetail();
		System.out.println(o.oid + " " + o.oname + " " + o.odate + " " + o.oprice);
		Customer c = p.addCustomerDetail();
		System.out.println(c.cid + " " +c.cnames+" "+c.ccontact);

	}
}
