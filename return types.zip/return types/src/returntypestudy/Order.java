package returntypestudy;

public class Order {
int oid;
String oname;
float odate;
double oprice;

}
