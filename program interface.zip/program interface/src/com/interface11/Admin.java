package com.interface11;

public class Admin {
	public static void main(String[] args) {
		Handlefileoperation h = new Read();
		h.processOperation();
		Handlefileoperation h1 = new Write();
		h1.processOperation();
		Handlefileoperation h2 = new Delete();
		h2.processOperation();
		Admin m = new Admin();

	}
}
