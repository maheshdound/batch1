package com.interface11;

public class Delete implements Handlefileoperation {
	@Override
	public void processOperation() {
		System.out.println("this is delete operation");

	}
}
