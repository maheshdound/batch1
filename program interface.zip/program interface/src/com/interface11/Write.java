package com.interface11;

public class Write implements Handlefileoperation {
	@Override
	public void processOperation() {
		System.out.println("this is write operation");
	}
}