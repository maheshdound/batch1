package com.interface11;

public interface Handlefileoperation {
	public abstract void processOperation();
}
