package com.interface11;

public class Read implements Handlefileoperation {
	@Override
	public void processOperation() {
		System.out.println("this is read operation");

	}
}
