package datatypes1;

public class Datatypes2 {
public byte b=10;
public short c=11;
public int d=12;
public long e=13;
public float f=11.11f;
public double g=12.12; 
public boolean flag=true;
public char h='k';
public String names="mahesh";
public void m1() {
	
	System.out.println("display m1 data types");
    String names="mahesh";
	String last="dound";
	System.out.println(names);
	System.out.println(last);
	Datatypes2 dt=new Datatypes2();
	System.out.println(dt.b);
	System.out.println(dt.c);
	System.out.println(dt.d);
	System.out.println(dt.e);
	System.out.println(dt.g);
	System.out.println(dt.flag);
	System.out.println(dt.h);
System.out.println(dt.names);

}
}
