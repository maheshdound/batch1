package datatypes4;

import datatypes1.Datatypes2;

public class Datatypes3 {
public static void main(String[] args) {
	System.out.println("print data types");
	Datatypes2 dt2=new Datatypes2();
	dt2.m1();
} 
}
