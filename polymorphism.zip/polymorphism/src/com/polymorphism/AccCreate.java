package com.polymorphism;

public class AccCreate {
	private static final void m1(int i) {
		System.out.println("saving acc");
	}

	private static final short m1(boolean a) {
		System.out.println("current acc");
		return 654;
	}

	public final int m1(float f, int i) {
		System.out.println("joint acc");
		return 10;
	}

	public static void main(String[] args) {
		AccCreate ac = new AccCreate();
		ac.m1(10);
		ac.m1(22.2f, 5);
		ac.m1(false);
		main('j');

	}
	public static void main(char args) {
		System.out.println("devolopers main");
		
	}
}
