package com.polymorphism;

public class Demo {
public void m1(int i) {
	System.out.println("single parameter of method overloading");
}
public void m1(int j,int k) {
	System.out.println("two parametr of method overloading");
}
public final int m1(int i,int j,int k) {
	System.out.println("method overloading return types method");
	return 20;}
	public static final float m1(float k) {
		System.out.println("method overloading return types");
		return 12.3f;	
}
	public static int m1(String a) {
		System.out.println("method overloading static");
	return 10;
	}
	public static void main(String[] args) {
		System.out.println("java main");
		Demo d=new Demo();
		main(10);
		d.m1(8, 6,8);
		d.m1(23.5f);
	}
	public static void main(int args) {
		System.out.println("devolopers main");
		Demo s=new Demo();
		s.m1(10);
		s.m1(11,12);
	}
}
