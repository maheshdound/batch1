package com.methodoverriding;

public class Testclass {
	public static void main(String[] args) {
		System.out.println("method overriding");
		A a = new A();
	//	a.m1();
	//	a.m2();
	//	a.m3();
	//	A a1 = new B();
	//	a1.m1();
	//	a1.m2();
	//	a1.m3();
	//	A a2 = new C();
	//	a2.m1();
	//	a2.m2();
	//	a2.m3();
	//	B b = new B();
	//	b.m1();
	//	b.m2();
	//	b.m3();
	//	b.m4();
	//	b.m5();
	//	B b1 = new C();
	//	b1.m1();
	//	b1.m2();
	//	b1.m3();
	//	b1.m4();
	//	b1.m5();
		C c = new C();
	//	c.m1();
		c.m2();
	//	c.m3();
	//	c.m4();
	//	c.m5();
	//	c.m6();
	}
}
