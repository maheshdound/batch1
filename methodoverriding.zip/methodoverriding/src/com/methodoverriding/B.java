package com.methodoverriding;

public class B extends A {
	@Override
	public void m2() {
		// TODO Auto-generated method stub
		System.out.println("override m2 method in class b");
		super.m2();
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		System.out.println("m3 override method in class b");
		super.m3();
	}

	public void m4() {
		System.out.println("m4 method of class B");
	}

	public void m5() {
		System.out.println("m5 method of class B");
	}
}
