package com.methodoverriding;

public class C extends B {
	@Override
	public void m2() {
		// TODO Auto-generated method stub
		System.out.println("override m2 method in class c");
		super.m2();
	}

	@Override
	public void m4() {
		// TODO Auto-generated method stub
		System.out.println("override m4 method in class c");
		super.m4();
	}

	public void m6() {
		System.out.println("m6 method of class c");
	}
}
