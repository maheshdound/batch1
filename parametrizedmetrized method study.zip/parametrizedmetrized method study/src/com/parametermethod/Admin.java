package com.parametermethod;

public class Admin {
	public void m1() {
		System.out.println("without parameter method");
	}

	public void m2(int i) {
		System.out.println("single parameter method");
		System.out.println(i);
	}

	public void m3(long l, char c) {
		System.out.println("two parameter method");
		System.out.println(l + " " + c);
	}

	public void m4(Boolean b, String s, float f) {
		System.out.println("three parametr method");
		System.out.println(b + " " + s + " " + f);

	}

	public void m5(byte j) {
		System.out.println(j);

	}

	public void displayHrDetail(Hr hr) {
		System.out.println("display hr detail");
		System.out.println(hr.hid + " " + hr.hnames);
	}

	public static void main(String[] args) {
		Admin m = new Admin();
		m.m1();
		m.m2(10);
		m.m3(876, 'h');
		m.m4(true, "mahesh", 65.7f);
		byte j = 87;
		m.m5(j);
		Hr hr = new Hr();
		hr.hid = 78;
		hr.hnames = "mahe";

		m.displayHrDetail(hr);
	}
}
