package com.parametermethod;

public class Hr {
	int hid;
	String hnames;
}
