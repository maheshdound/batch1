package com.stringstudy;

public class StringTest {
	//String is emmutable means it can not modified or unchangable
public static void main(String[] args) {
	//java string is basically an object which represent seqence of char value.
	//array of character works same as javastring
	//char[] array={'s','d','f'};
	//String s=new String(array);
	String s="hi welcome to string";
	//created by using literals,stored instring constant pool(scp)
	//SCP is memory location
	System.out.println(s);
	String s1=new String("lmn");
	//created by using new keyword
	//stored in heap memory
	System.out.println(s1);
	
	//length method() in string class 
	//length method returns the number of characters present in the string.
	//lenght method also count the space
	//int length = s.length();
	String m="THIS IS STRING";
	String n="this is string";
	String o=new String("is string");
	System.out.println(o.length());//output=20
	//use lenght method to find the size of string.
	//use to compare size of string.
	//int len1=m.length();
	//int len2=n.length();
	if (m.length()==o.length()) {
		System.out.println("both are same");
	}else {
		System.out.println("not same");
	}//== compare the size of string
	
	//toupperCase();
	String upperc=s.toUpperCase();
	System.out.println(upperc);
	System.out.println(s.toUpperCase());
	System.out.println(m.toLowerCase());
	
	//toUppercase and toLowerCase method is use for conver the string 
	//upper case to lower case
	
	//equals method
	//equal method compare to string and return true if string are equal and 
	//faulse if string are not equal.
	String oldclgname="MIT";
	String newclgname="mit";
	String ss=new String("MIT");
	if (oldclgname.equals(ss)) {
		System.out.println("both String are same");
		
	}else {
		System.out.println("not same");
	}
	//.equal method compare the string
	//equal ignore method
	
	//-compairing the two string string ignoring the uppercase and lower case
	//diffrences
	System.out.println("equal ignore study");
	if (oldclgname.equalsIgnoreCase(newclgname))
		System.out.println("same");
	else
	   System.out.println("not same");
	
	
	
	
	
	//indexof method
	char ch=oldclgname.charAt(2);
	System.out.println(ch);
	System.out.println(s.indexOf("w"));
	// this method is used to find the idexof of these character in string.
	
	
	//chararray method-char[]arrayofchar={'s','s','d'}
	//char array method-convert the string into characters. 
	//the char array method is used to break the string into an individual 
	//characters
	//for each loops iterates for the array and print each character on new line.
	char[] arraychar=oldclgname.toCharArray();
	//char[] arraychar = {'s','d','j'};
	System.out.println(arraychar);
	//for (char c : arraychar)
	//System.out.println(c);
	  
	
	//trim method()
	//trim method is used to remove string whitespaces from starting and 
	//ending of string,not removed middle spaces.
	
	
	String uName="abc123  ";
	uName=uName.trim();
	//System.out.println(uName);
	if(uName.equals("abc123"));{
	System.out.println("successfull login");
    }
	//else {
		//System.out.println("invalid username");
	//}
		
	//substring method
	//substring method are used to return a substring from given string.
	//this method takes the one parameter for starting the substring 
	//end parameter for end of string.
	//when the end parameter is not specified then substring is end at the end 
	//of main string.
	
	String s5="hi welcome to string";
	String s6=s5.substring(2);
	System.out.println(s6);
	System.out.println(s5.substring(2,5)); 
	//if we provide invalid index then method will throw out of boundexception.
	//if the start index value is equal to end index value then 
	//then substring method return empty index.
	
	
	//split method
	//split method split a string into an array of substring 
	
	
	//String s5="welcome to string";
	String[]array1= s5.split("to");
	for(String string:array1){
	System.out.println(string);
	}
	System.out.println(array1.length);
	System.out.println(s5.length());
	
	
   //startwith endwith method
   //the start with method is used to checked the specified string is start 
   //with specified characters
   //the endwith()is used to checked if the string is end with specified suffix
   //this method retains eighter true or false	
	System.out.println(s5.startsWith("hi"));
	System.out.println(s5.endsWith("e"));
	
	
	
	
	
	
}
}
