package com.stringvalidation;
import java.util.Scanner;
public class Validation {
public static void main(String[] args) {
	//String name="mahesh";
	Scanner sc=new Scanner(System.in);
	System.out.println("mobile number: ");
	String str=sc.next();
	if (str.matches("[0-9]{10}"))
			System.out.println("given string is proper name");
	else
		System.out.println("improper");
}
}
