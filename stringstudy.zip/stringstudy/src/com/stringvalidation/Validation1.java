package com.stringvalidation;
import java.util.Iterator;
import java.util.Scanner;
public class Validation1 {
public static void main(String[] args) {
	//Scanner sc=new Scanner(System.in);
	String name="maHesh@2";
	//System.out.println("enter your name");
	//String str=sc.next();
	boolean flag=true;
	char[] ch=name.toCharArray();
	for (int j = 0; j < ch.length; j++) {
		
	
	if (!(name.charAt(j)>='a'&& name.charAt(j)>='z')) {
		flag =false;
	}
	}
	if (!flag){
		System.out.println("proper name");
	}else {
		System.out.println("improper name");
	}
	
}
}
