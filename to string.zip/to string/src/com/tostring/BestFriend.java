package com.tostring;

public class BestFriend {
	public String names;
	public int age;
	public String collage;
	public String address;
	public long contact;

	public BestFriend(String names, int age, String collage, String address, long contact) {
		
		this.names = names;
		this.age = age;
		this.collage = collage;
		this.address = address;
		this.contact = contact;
	
	
	}
	
	@Override
	public String toString() {
		return "BestFriend [names=" + names + ", age=" + age + ", collage=" + collage + ", address=" + address
				+ ", contact=" + contact + "]";
	}

	public static void main(String[] args) {
		BestFriend b = new BestFriend("mahesh", 32, "pcmc", "pune", 978655);
		
		System.out.println(b.toString());

	}



}
