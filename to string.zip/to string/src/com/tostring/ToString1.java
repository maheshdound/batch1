package com.tostring;

public class ToString1 {
	public String names;
	public int age;
	public String collage;
	public String address;
	public long contact;
	public String getNames() {
		return names;
	}
	public void setNames(String names) {
		this.names = names;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCollage() {
		return collage;
	}
	public void setCollage(String collage) {
		this.collage = collage;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "ToString1 [names=" + names + ", age=" + age + ", collage=" + collage + ", address=" + address
				+ ", contact=" + contact + "]";
	}
public static void main(String[] args) {
	ToString1 t =new ToString1();
	t.setNames("mahesh");
	t.setAge(33);
	t.setCollage("pccoe");
	t.setAddress("pune");
	t.setContact(877656);
	System.out.println(t.toString());
}
}
