package com.methodoverriding;

public class Electronics extends Product {
	@Override
	public void displayDetail() {
		System.out.println("Electronics product is freez");
	}

	@Override
	public void shippingCost() {
		System.out.println("shipping cost is 5 doller");
	}
}
