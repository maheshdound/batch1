package com.methodoverriding;

public class Admin {
	public static void main(String[] args) {
		System.out.println("electronics product detail");
		Product p = new Electronics();
		p.displayDetail();
		p.shippingCost();
		System.out.println("clothing product detail");
		Product p1 = new Clothing();
		p1.displayDetail();
		p1.shippingCost();
		System.out.println("groceries detail");
		Product p2 = new Groceries();
		p2.displayDetail();
		p2.shippingCost();
	}
}
