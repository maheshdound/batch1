package com.methodoverriding;

public class Groceries extends Product {
	@Override
	public void displayDetail() {
		System.out.println("grocery product is icecreme");

	}

	@Override
	public void shippingCost() {
		System.out.println("shipping cost is 15 doller");
	}
}
