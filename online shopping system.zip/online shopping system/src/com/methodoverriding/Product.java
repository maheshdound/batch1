package com.methodoverriding;

public class Product {
	public void displayDetail() {
		System.out.println("default product detail");
	}

	public void shippingCost() {
		System.out.println("default shipping cost in doller");
	}
}
