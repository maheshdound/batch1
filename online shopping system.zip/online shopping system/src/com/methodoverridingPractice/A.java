package com.methodoverridingPractice;

public class A {
	public void m1() {
		System.out.println("this is parent m1 method");
	}

	public void m2(int i) {
		System.out.println("this is parent parameter m2 method");

	}

	public int m3() {
		System.out.println("this is parent return types m3 method ");
		return 10;
	}

	public static float m4(int i) {
		System.out.println("this is parent static m4 method");
		return 10.5f;
	}

	private void m5() {
		System.out.println("access modifier parent");
	}
}