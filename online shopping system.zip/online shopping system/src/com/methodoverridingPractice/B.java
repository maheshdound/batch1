package com.methodoverridingPractice;

public class B extends A {
	@Override
	public void m1() {
		System.out.println("modified m1");
	}

	@Override
	public void m2(int i) {
		System.out.println("modified m2");
	}

	@Override
	public int m3() {
		System.out.println("modified m3");
		return 28;
	}

	public static float m4(int i) {
		System.out.println("child this is static m4 method");
		return 10.5f;
	}

	public void m5() {
		System.out.println("access modifier");
	}
public static void main(String[] args) {
//	A.m4(77);
//	B.m4(98);
//	A a=new A();
//	a.m1();
//	a.m2(11);
//	a.m3();
//	A s=new B();
//	s.m1();
//	s.m2(23);
//	s.m3();
//	s.m4(33);
	B b=new B();
	b.m4(34);
	b.m1();
	b.m2(55);
	b.m3();
	b.m5();
	A.m4(33);

}
}
